﻿namespace TwitterAssignmentApi.Models
{
    public enum ReactionType
    {
        Thumsup = 1,
        Heart,
        Angry,
        Smile
    }
}