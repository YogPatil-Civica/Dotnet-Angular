﻿namespace TwitterAssignmentApi.Dtos
{
    public class LoginUserDto
    {
        public string LoginId { get; set; }

        public string Password { get; set; }
    }
}
